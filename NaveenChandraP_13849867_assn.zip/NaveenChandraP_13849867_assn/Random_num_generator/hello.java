package task1;
import java.util.Random; 
import java.util.Scanner;
import java.io.*;

/**
 * hello
 */
public class hello {

     public static void main(String[] args) throws FileNotFoundException  {
          
        long ll, ul;
        long num;
        Scanner sc=new Scanner(System.in);
        PrintStream o = new PrintStream(new File("C:/Users/navee/Desktop/algorithms/task1/p5.txt"));
        ll = sc.nextLong();
        ul = sc.nextLong();
        num = sc.nextLong();
        long startTime = System.currentTimeMillis();
        long [] sris= new long [(int) num];
       sris = rNGenerator(ll,ul,num);
       System.setOut(o);  
       for(int i=0;i<num;i++)
       System.out.println(sris[i]);
       long endTime = System.currentTimeMillis();
       long timeElapsed = endTime - startTime;
       System.out.print(timeElapsed);
     }
public static long [] rNGenerator (long lowerLimit, long upperLimit, long numOfValues)
{ 
            long r;
            long [] s= new long [(int) numOfValues];
            Random rand = new Random();
            for (int i=0 ; i < numOfValues; i++)
            {
                r = (long)(rand.nextInt((int)upperLimit - (int)lowerLimit) + (int)lowerLimit);
                if(dupli(s,r)==false)
                {
                    s[i]=r;
                }
                else
                {
                     i--;
                }
            }
            
            return s;      
}
public static boolean dupli(long [] arr, long rand)
{
     for(int i=0;i<arr.length;i++)
     {
          if(arr[i]==rand)
          {
               return true;
          }
     }
     return false;
} 
}