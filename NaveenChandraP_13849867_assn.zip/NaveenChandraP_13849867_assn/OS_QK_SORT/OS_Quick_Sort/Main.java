
import java.util.Random; 
import java.util.Scanner;
import java.io.*;
/**
 * task21
 */
public class Main {

    public static void main(String[] args) {
        
        long ll, ul;
        long num;
        Scanner sc=new Scanner(System.in);
        ll = sc.nextLong();
        ul = sc.nextLong();
        num = sc.nextLong();
        long startTime = System.currentTimeMillis();
        long [] sris= new long [(int) num];
       sris = rNGenerator(ll,ul,num);
       QSort(sris,0,sris.length-1);
       try {
        PrintStream K = new PrintStream(new File("T5.txt"));
        System.setOut(K);
    } catch (Exception e) {
        //TODO: handle exception
        e.printStackTrace();
    }
       for(int i=0;i<num;i++)
       System.out.println(sris[i]);
       long endTime = System.currentTimeMillis();
       long timeElapsed = endTime - startTime;
         
       System.out.print((timeElapsed/1000) + "s"); 
    }
    public static long [] rNGenerator (long lowerLimit, long upperLimit, long numOfValues)
    { 
                long r;
                long [] s= new long [(int) numOfValues];
                Random rand = new Random();
                for (int i=0 ; i < numOfValues; i++)
                {
                    r = (long)(rand.nextInt((int)upperLimit - (int)lowerLimit) + (int)lowerLimit);
                    if(dupli(s,r)==false)
                    {
                        s[i]=r;
                    }
                   else
                    {
                         i--;
                    }
                }
                
                return s;      
    }
    public static boolean dupli(long [] arr, long rand)
    {
         for(int i=0;i<arr.length;i++)
         {
              if(arr[i]==rand)
              {
                   return true;
              }
         }
         return false;
    } 
     public static void QSort(long [] arr, long low, long high)
     {
        if (low < high) 
        { 
            long pi = partition(arr, low, high); 
            QSort(arr, low, pi-1); 
            QSort(arr, pi+1, high); 
        } 
     } 
     public static long partition(long [] arr, long low, long high) 
     { 
         Long pivot = arr[(int)high];  
         long i = (low-1); 
         for (long j=low; j<high; j++) 
         {  
             if (arr[(int)j] < pivot) 
             { 
                 i++; 
                 Long temp = arr[(int)i]; 
                 arr[(int)i] = arr[(int)j]; 
                 arr[(int)j] = temp; 
             } 
         } 
         Long temp = arr[(int)i+1]; 
         arr[(int)i+1] = arr[(int)high]; 
         arr[(int)high] = temp; 
         return i+1; 
     } 
     }  